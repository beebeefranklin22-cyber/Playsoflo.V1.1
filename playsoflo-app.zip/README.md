# PlaySoFlo

Fresh rebuild. Social feed (posts/photos/reels/livestreams) is the home screen;
ride-hailing, music, wallet, and other mini apps live under `/apps` with their
own nav — same Next.js project, Option A architecture.

## Setup

1. **Supabase**: already created. Run `supabase/schema.sql` then
   `supabase/feed_view.sql` in the SQL Editor (in that order).
2. **Env vars**: rename `.env.local.example` to `.env.local` for local dev.
   In Vercel, add the same two keys under Project Settings → Environment Variables.
3. **Deploy**: push this repo to GitHub, then import it into a new Vercel project.

## Structure

- `app/page.tsx` — social feed (reads the `feed_items` view)
- `app/profile/[username]/page.tsx` — Instagram-style grid profile
- `app/live/[id]/page.tsx` — livestream viewer (Agora plugs in here)
- `app/apps/*` — mini apps (rides, music, wallet), separate nav from the feed
- `components/BottomNav.tsx` — shell navigation
- `lib/supabase-*.ts` — Supabase clients (browser + server)

## Not yet built (next passes)

- Auth screens (sign up / log in)
- Post/photo/reel creation flows
- Agora livestream integration + gifting animations
- Push notifications for "went live" events
