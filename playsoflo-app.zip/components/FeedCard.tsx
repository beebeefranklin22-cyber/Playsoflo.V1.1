import Link from 'next/link';

const typeLabel: Record<string, string> = {
  post: '',
  photo: '',
  reel: 'Reel',
  stream: 'LIVE',
};

export default function FeedCard({ item }: { item: any }) {
  const isLive = item.content_type === 'stream';
  const author = item.profiles?.username ?? 'unknown';

  return (
    <article className="rounded-xl2 border border-line bg-surface p-4">
      <div className="flex items-center justify-between mb-2">
        <Link href={`/profile/${author}`} className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-surface2" />
          <span className="text-sm text-white">{author}</span>
        </Link>
        {isLive && (
          <span className="text-xs font-medium text-magenta border border-magenta rounded-full px-2 py-0.5">
            LIVE
          </span>
        )}
        {!isLive && typeLabel[item.content_type] && (
          <span className="text-xs text-mist">{typeLabel[item.content_type]}</span>
        )}
      </div>

      {item.media_urls?.[0] && (
        <div className="rounded-xl overflow-hidden mb-2 bg-surface2 aspect-square" />
      )}

      {item.text && <p className="text-sm text-mist">{item.text}</p>}

      {isLive && (
        <Link
          href={`/live/${item.id}`}
          className="mt-3 inline-block text-sm text-violet"
        >
          Watch stream →
        </Link>
      )}
    </article>
  );
}
