'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const items = [
  { href: '/', label: 'Feed' },
  { href: '/discover', label: 'Discover' },
  { href: '/live/new', label: 'Go Live' },
  { href: '/apps', label: 'Apps' },
  { href: '/profile/me', label: 'Profile' },
];

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-line bg-surface/95 backdrop-blur">
      <ul className="flex items-center justify-between px-4 py-3 max-w-md mx-auto">
        {items.map((item) => {
          const active = pathname === item.href;
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                className={`text-xs tracking-tight ${
                  active ? 'text-magenta' : 'text-mist'
                }`}
              >
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
