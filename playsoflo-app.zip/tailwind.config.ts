import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        void: '#0B0714',      // near-black base
        surface: '#161022',   // card/panel surface
        surface2: '#1F1830',  // raised surface
        violet: '#8B5CF6',    // primary accent
        magenta: '#D946A6',   // secondary accent (gifting/live)
        mist: '#A9A3BC',      // muted text
        line: '#2A2240',      // hairline borders
      },
      fontFamily: {
        display: ['var(--font-display)'],
        body: ['var(--font-body)'],
      },
      borderRadius: {
        xl2: '1.25rem',
      },
    },
  },
  plugins: [],
};

export default config;
