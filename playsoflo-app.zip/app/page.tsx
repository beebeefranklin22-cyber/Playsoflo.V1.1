import { createClient } from '@/lib/supabase-server';
import FeedCard from '@/components/FeedCard';

export const dynamic = 'force-dynamic';

export default async function FeedPage() {
  const supabase = createClient();

  const { data: items, error } = await supabase
    .from('feed_items')
    .select('*, profiles(username, avatar_url)')
    .order('created_at', { ascending: false })
    .limit(30);

  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <h1 className="font-display text-2xl mb-6 text-white">PlaySoFlo</h1>

      {error && (
        <p className="text-mist text-sm">
          Feed isn&apos;t loading yet — run the <code>feed_items</code> view SQL in Supabase.
        </p>
      )}

      {!error && (!items || items.length === 0) && (
        <p className="text-mist text-sm">
          No posts yet. Be the first to post, drop a reel, or go live.
        </p>
      )}

      <div className="flex flex-col gap-4">
        {items?.map((item: any) => (
          <FeedCard key={`${item.content_type}-${item.id}`} item={item} />
        ))}
      </div>
    </main>
  );
}
