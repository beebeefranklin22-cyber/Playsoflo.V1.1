import { createClient } from '@/lib/supabase-server';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function ProfilePage({
  params,
}: {
  params: { username: string };
}) {
  const supabase = createClient();

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('username', params.username)
    .single();

  if (!profile) notFound();

  const { data: gridItems } = await supabase
    .from('feed_items')
    .select('*')
    .eq('user_id', profile.id)
    .neq('content_type', 'stream') // grid shows posts/photos/reels, not live sessions
    .order('created_at', { ascending: false });

  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <div className="flex items-center gap-4 mb-6">
        <div className="h-20 w-20 rounded-full bg-surface2 border border-line" />
        <div>
          <h1 className="font-display text-xl text-white">{profile.display_name ?? profile.username}</h1>
          <p className="text-mist text-sm">@{profile.username}</p>
        </div>
      </div>

      {profile.bio && <p className="text-sm text-mist mb-6">{profile.bio}</p>}

      <div className="grid grid-cols-3 gap-1">
        {gridItems?.map((item: any) => (
          <div
            key={`${item.content_type}-${item.id}`}
            className="aspect-square bg-surface2 border border-line"
          />
        ))}
      </div>

      {(!gridItems || gridItems.length === 0) && (
        <p className="text-mist text-sm text-center mt-10">No posts yet.</p>
      )}
    </main>
  );
}
