import { createClient } from '@/lib/supabase-server';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function LiveStreamPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: stream } = await supabase
    .from('streams')
    .select('*, profiles(username)')
    .eq('id', params.id)
    .single();

  if (!stream) notFound();

  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <div className="aspect-[9/16] bg-surface2 rounded-xl2 border border-line mb-3" />
      <h1 className="font-display text-lg text-white">{stream.title ?? 'Live stream'}</h1>
      <p className="text-mist text-sm">@{stream.profiles?.username}</p>
      <p className="text-mist text-xs mt-4">
        Agora video, flowing comments, reactions, and gifting UI plug in here.
      </p>
    </main>
  );
}
