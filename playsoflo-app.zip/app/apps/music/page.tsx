export default function MusicPage() {
  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <h1 className="font-display text-2xl mb-2 text-white">Music</h1>
      <p className="text-mist text-sm">Music browsing mini app placeholder — catalog plugs in here.</p>
    </main>
  );
}
