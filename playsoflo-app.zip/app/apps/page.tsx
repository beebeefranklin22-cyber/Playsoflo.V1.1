import Link from 'next/link';

const apps = [
  { href: '/apps/rides', name: 'Rides', blurb: 'Book a ride around South Florida' },
  { href: '/apps/music', name: 'Music', blurb: 'Browse and stream local artists' },
  { href: '/apps/wallet', name: 'Wallet', blurb: 'Coins, gifting, and cash out' },
];

export default function AppsHub() {
  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <h1 className="font-display text-2xl mb-6 text-white">Apps</h1>
      <div className="flex flex-col gap-3">
        {apps.map((app) => (
          <Link
            key={app.href}
            href={app.href}
            className="rounded-xl2 border border-line bg-surface p-4 flex flex-col"
          >
            <span className="text-white font-medium">{app.name}</span>
            <span className="text-mist text-sm">{app.blurb}</span>
          </Link>
        ))}
      </div>
    </main>
  );
}
