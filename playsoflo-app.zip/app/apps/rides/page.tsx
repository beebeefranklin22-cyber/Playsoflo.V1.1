export default function RidesPage() {
  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <h1 className="font-display text-2xl mb-2 text-white">Rides</h1>
      <p className="text-mist text-sm">Ride-hailing mini app placeholder — booking flow plugs in here.</p>
    </main>
  );
}
