import { createClient } from '@/lib/supabase-server';

export const dynamic = 'force-dynamic';

export default async function WalletPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  let balance = 0;
  if (user) {
    const { data } = await supabase
      .from('wallets')
      .select('coin_balance')
      .eq('user_id', user.id)
      .single();
    balance = data?.coin_balance ?? 0;
  }

  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <h1 className="font-display text-2xl mb-6 text-white">Wallet</h1>
      <div className="rounded-xl2 border border-line bg-surface p-6 text-center">
        <p className="text-mist text-sm mb-1">Coin balance</p>
        <p className="text-4xl font-display text-magenta">{balance}</p>
      </div>
      <p className="text-mist text-sm mt-4">
        Buy coins and cash-out flows plug in here via Stripe.
      </p>
    </main>
  );
}
