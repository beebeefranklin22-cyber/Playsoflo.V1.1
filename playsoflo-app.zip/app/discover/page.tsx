import { createClient } from '@/lib/supabase-server';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function DiscoverPage() {
  const supabase = createClient();
  const { data: profiles } = await supabase
    .from('profiles')
    .select('username, display_name')
    .limit(20);

  return (
    <main className="max-w-md mx-auto px-4 pt-6">
      <h1 className="font-display text-2xl mb-6 text-white">Discover</h1>
      <div className="flex flex-col gap-2">
        {profiles?.map((p: any) => (
          <Link
            key={p.username}
            href={`/profile/${p.username}`}
            className="rounded-xl border border-line bg-surface p-3 text-white"
          >
            @{p.username}
          </Link>
        ))}
      </div>
    </main>
  );
}
