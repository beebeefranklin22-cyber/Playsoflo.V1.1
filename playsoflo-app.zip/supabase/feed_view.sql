create or replace view public.feed_items as
select id, user_id, 'post' as content_type, caption as text, null::text[] as media_urls, created_at
from public.posts
union all
select id, user_id, 'photo', caption, media_urls, created_at
from public.photos
union all
select id, user_id, 'reel', caption, array[video_url], created_at
from public.reels
union all
select id, host_id as user_id, 'stream', title, null::text[], started_at as created_at
from public.streams
where is_live = true;
