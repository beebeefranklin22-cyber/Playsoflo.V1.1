-- =========================================================
-- PLAYSOFLO — CORE SCHEMA (fresh Supabase project)
-- =========================================================
-- Run this in Supabase SQL Editor, top to bottom.
-- Uses Supabase's built-in auth.users table for identity.

-- ---------- USERS / PROFILES ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text,
  avatar_url text,
  bio text,
  created_at timestamptz default now()
);

create index idx_profiles_username on public.profiles(username);

-- ---------- FOLLOWS ----------
create table public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  followed_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (follower_id, followed_id)
);

create index idx_follows_followed on public.follows(followed_id);

-- ---------- POSTS (text/caption + reposts) ----------
create table public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  caption text,
  repost_of uuid references public.posts(id),
  created_at timestamptz default now()
);

-- ---------- PHOTOS (single or multi-media) ----------
create table public.photos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  media_urls text[] not null,       -- supports multiple photos/videos in one post
  caption text,
  filter_applied text,
  text_overlay text,
  created_at timestamptz default now()
);

-- tagging people in photos (tap-to-reveal style)
create table public.photo_tags (
  id uuid primary key default gen_random_uuid(),
  photo_id uuid references public.photos(id) on delete cascade,
  tagged_user_id uuid references public.profiles(id) on delete cascade,
  x_position numeric,   -- 0-1 relative coordinates
  y_position numeric
);

-- ---------- REELS ----------
create table public.reels (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  video_url text not null,
  caption text,
  duration_seconds numeric,
  music_track_id uuid,        -- FK to music mini app's tracks table
  filter_applied text,
  created_at timestamptz default now()
);

-- ---------- LIVESTREAMS ----------
create table public.streams (
  id uuid primary key default gen_random_uuid(),
  host_id uuid references public.profiles(id) on delete cascade,
  title text,
  is_live boolean default true,
  is_paused boolean default false,
  cohost_ids uuid[] default '{}',
  started_at timestamptz default now(),
  ended_at timestamptz
);

create table public.stream_comments (
  id uuid primary key default gen_random_uuid(),
  stream_id uuid references public.streams(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  message text not null,
  created_at timestamptz default now()
);

create table public.stream_reactions (
  id uuid primary key default gen_random_uuid(),
  stream_id uuid references public.streams(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  emoji text not null,
  created_at timestamptz default now()
);

-- ---------- UNIFIED INTERACTIONS (likes/comments/shares across all content types) ----------
create table public.interactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post','photo','reel','stream')),
  target_id uuid not null,
  interaction_type text not null check (interaction_type in ('like','comment','share')),
  comment_text text,           -- only used when interaction_type = 'comment'
  created_at timestamptz default now()
);

create index idx_interactions_target on public.interactions(target_type, target_id);

-- ---------- VIRTUAL GIFTING ----------
create table public.gift_catalog (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  icon_url text,
  coin_cost integer not null
);

create table public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  coin_balance integer default 0 not null
);

create table public.gift_transactions (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid references public.profiles(id) on delete cascade,
  receiver_id uuid references public.profiles(id) on delete cascade,
  gift_id uuid references public.gift_catalog(id),
  stream_id uuid references public.streams(id),
  coin_amount integer not null,
  created_at timestamptz default now()
);

-- ---------- NOTIFICATIONS (e.g. "X went live") ----------
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid references public.profiles(id) on delete cascade,
  type text not null,           -- 'went_live', 'new_follower', 'gift_received', etc.
  actor_id uuid references public.profiles(id),
  reference_id uuid,            -- e.g. stream_id
  is_read boolean default false,
  created_at timestamptz default now()
);

create index idx_notifications_recipient on public.notifications(recipient_id, is_read);

-- =========================================================
-- ROW LEVEL SECURITY (baseline — tighten later)
-- =========================================================
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.photos enable row level security;
alter table public.reels enable row level security;
alter table public.streams enable row level security;
alter table public.interactions enable row level security;
alter table public.wallets enable row level security;
alter table public.gift_transactions enable row level security;
alter table public.notifications enable row level security;

create policy "Public read profiles" on public.profiles for select using (true);
create policy "Users update own profile" on public.profiles for update using (auth.uid() = id);

create policy "Public read posts" on public.posts for select using (true);
create policy "Users create own posts" on public.posts for insert with check (auth.uid() = user_id);

create policy "Public read photos" on public.photos for select using (true);
create policy "Users create own photos" on public.photos for insert with check (auth.uid() = user_id);

create policy "Public read reels" on public.reels for select using (true);
create policy "Users create own reels" on public.reels for insert with check (auth.uid() = user_id);

create policy "Public read streams" on public.streams for select using (true);
create policy "Users create own streams" on public.streams for insert with check (auth.uid() = host_id);

create policy "Public read interactions" on public.interactions for select using (true);
create policy "Users create own interactions" on public.interactions for insert with check (auth.uid() = user_id);

create policy "Users see own wallet" on public.wallets for select using (auth.uid() = user_id);

create policy "Users see own notifications" on public.notifications for select using (auth.uid() = recipient_id);

-- =========================================================
-- TRIGGER: auto-notify followers when a stream goes live
-- =========================================================
create or replace function public.notify_followers_on_live()
returns trigger as $$
begin
  if new.is_live = true then
    insert into public.notifications (recipient_id, type, actor_id, reference_id)
    select follower_id, 'went_live', new.host_id, new.id
    from public.follows
    where followed_id = new.host_id;
  end if;
  return new;
end;
$$ language plpgsql security definer;

create trigger trg_notify_followers_on_live
after insert on public.streams
for each row execute function public.notify_followers_on_live();
